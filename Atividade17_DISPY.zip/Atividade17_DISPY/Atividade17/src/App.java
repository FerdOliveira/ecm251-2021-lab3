/**
 * @author Gustavo Zamboni do Carmo 19.01266-7
 * @author Raphael Marchetti Calciolari 19.00828-7
 * @author Fernando Oliveira de Souza 19.00617-9
 * @author Matheus Takahashi Nakai 19.01355-8
 */

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
    }
}
