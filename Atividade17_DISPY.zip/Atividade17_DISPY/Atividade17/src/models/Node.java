package models;

/**
 * @author Gustavo Zamboni do Carmo 19.01266-7
 * @author Raphael Marchetti Calciolari 19.00828-7
 * @author Fernando Oliveira de Souza 19.00617-9
 * @author Matheus Takahashi Nakai 19.01355-8
 */

public class Node {
    public Integer data;
    public Node next;

    public Node(Integer data){
        this.data = data;
        this.next = null;
    }
}
