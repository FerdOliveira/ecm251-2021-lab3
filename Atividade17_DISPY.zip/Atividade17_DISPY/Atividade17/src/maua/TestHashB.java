package maua;

import java.util.ArrayList;

/**
 * @author Gustavo Zamboni do Carmo 19.01266-7
 * @author Raphael Marchetti Calciolari 19.00828-7
 * @author Fernando Oliveira de Souza 19.00617-9
 * @author Matheus Takahashi Nakai 19.01355-8
 */

public class TestHashB {
    static Integer numKey = 100000;
    static Integer numHash = 1000;
    public static void main(String[] args) {
        Integer[] tabKeys = new Integer[numKey];
        ArrayList<SList> tabHash = new ArrayList<>();
        //inserindo chaves de 0 a numKey
        for (int i = 0; i < numKey; i++) {
            tabKeys[i] = i;
        }
        //inicializando listas ligadas nulas para todas as posicoes
        for (int i = 0; i < numHash; i++) {
            tabHash.add(new SList());
        }

        //fazendo o hashing e armazenando as chaves na tabela associativa
        for (int i = 1; i < tabKeys.length; i++) {
            Integer hashKey = hash(tabKeys[i]);
            tabHash.get(hashKey).InsereInicio(tabKeys[i]);
        }

        for (SList list: tabHash) {
            System.out.printf("Slot %d: ",tabHash.indexOf(list));
            list.printList();
            System.out.println();
        }
    }
    public static Integer hash(Integer key) {
        return (key % numHash);
    }
}
