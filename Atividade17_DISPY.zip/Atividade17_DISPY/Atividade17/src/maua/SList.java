package maua;

import models.Node;

/**
 * @author Gustavo Zamboni do Carmo 19.01266-7
 * @author Raphael Marchetti Calciolari 19.00828-7
 * @author Fernando Oliveira de Souza 19.00617-9
 * @author Matheus Takahashi Nakai 19.01355-8
 */

public class SList {
    private Node head;

    public SList(){
        this.head = null;
    }

    public void InsereInicio(Integer data){
        Node newNode = new Node(data);

        if(this.head == null)
            this.head = newNode;
        else{
            Node last = this.head;
            while(last.next!=null){
                last = last.next;
            }
            last.next = newNode;
        }
    }
    public void printList(){
        Node cNode = this.head;
        System.out.printf("[\t");
        while (cNode != null){
            System.out.printf("%d\t",cNode.data);
            cNode = cNode.next;
        }
        System.out.printf("]");
    }
}
