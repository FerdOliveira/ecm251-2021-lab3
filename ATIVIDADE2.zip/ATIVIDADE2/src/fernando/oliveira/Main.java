package fernando.oliveira;

import fernando.oliveira.sistema.Login;

import java.io.IOException;

/**
 * @author Carolina de Carvalho Gutierrez Ra: 18.00576-4
 * @author Fernando Oliveira de Souza     Ra: 19.00617-9
 * @author Guilherme Bernardelli Zeigler  Ra: 19.02453-3
 */
public class Main {
    public static void main(String[] args) throws IOException {
        Login.run();
    }
}
