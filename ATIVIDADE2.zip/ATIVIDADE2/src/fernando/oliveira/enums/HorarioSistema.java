package fernando.oliveira.enums;

/**
 * Enum para determinar se o horário do sistema é EXTRA ou NORMAL
 */
public enum HorarioSistema {
    EXTRA, NORMAL;
}
