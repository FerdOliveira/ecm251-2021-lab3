package fernando.oliveira.Interface;

/**
 * Interface de Apresentacao de todos os membros, implementada em membros
 */
public interface ApresentacaoMembros {
    public void apresentacao();
}
